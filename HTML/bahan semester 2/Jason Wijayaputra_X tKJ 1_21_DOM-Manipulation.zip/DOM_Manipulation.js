const title = document.getElementById('judul');
title.innerHTML = '<em>Jason Wijayaputra</em>';

const section_a = document.querySelector('section#a');
section_a.innerHTML = 'Hello World!';


const judul = document.getElementsByTagName('h1')[0];
const w = document.querySelector('section#a a');





